package septagram.Theomachy.DB;

public interface PluginData
{
	final static String version = "TMA Delta Edition"; 
	final static String buildnumber = "20160525";
}
