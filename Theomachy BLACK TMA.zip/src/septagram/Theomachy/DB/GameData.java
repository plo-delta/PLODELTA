package septagram.Theomachy.DB;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.bukkit.Location;
import org.bukkit.entity.Player;

import septagram.Theomachy.Ability.Ability;

public class GameData
{
	public static HashMap<String,Player> OnlinePlayer = new HashMap<String,Player>(); 
	public static HashMap<String,Ability> PlayerAbility = new HashMap<String,Ability>(); 
	public static HashMap<String,String> PlayerTeam = new HashMap<String,String>(); 
	public static HashMap<String,Location> SpawnArea = new HashMap<String,Location>(); 
	public static HashMap<Location, String> Core = new HashMap<Location, String>();
	public static List<String> Managers=new ArrayList<String>();
}
