package septagram.Theomachy.DB;

public interface AbilityData
{
	int ABILITY_NUMBER=62;
	int GOD_ABILITY_NUMBER=21;
	int HUMAN_ABILITY_NUMBER=41;
}
