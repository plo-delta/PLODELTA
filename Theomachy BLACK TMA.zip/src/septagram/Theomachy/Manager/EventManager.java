package septagram.Theomachy.Manager;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Snowball;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;

import septagram.Theomachy.Theomachy;
import septagram.Theomachy.Ability.Ability;
import septagram.Theomachy.DB.GameData;
import septagram.Theomachy.Handler.CommandModule.CoreSetting;
import septagram.Theomachy.Handler.CommandModule.Gambling;
import septagram.Theomachy.Handler.CommandModule.GameHandler;
import septagram.Theomachy.Utility.GetPlayerList;

@SuppressWarnings("deprecation")
public class EventManager implements Listener
{
	@EventHandler
	public static void onProjectileLaunch(ProjectileLaunchEvent event)
	{
		if (event.getEntity() instanceof Arrow)
		{
			Arrow arrow = (Arrow) event.getEntity();
			if (arrow.getShooter() instanceof Player)
			{
				Player player = (Player) arrow.getShooter();
				Ability ability = GameData.PlayerAbility.get(player.getName());
				if (ability != null && ability.abilityCode ==118)
					ability.T_Passive(event, player);
			}
		}
	}
	
	@EventHandler
	public static void onProjectileLaunch_(ProjectileLaunchEvent event)
	{
		if (event.getEntity() instanceof Projectile)
		{
			Projectile arrow = (Projectile) event.getEntity();
			if (arrow.getShooter() instanceof Player)
			{
				Player player = (Player) arrow.getShooter();
				Ability ability = GameData.PlayerAbility.get(player.getName());
				if (ability != null && ability.abilityCode ==141)
					ability.T_Passive(event);
			}
		}
	}
	
	@EventHandler
	public static void onPlayerInteractEvent(PlayerInteractEvent event)
	{
		Action a = event.getAction();
		Player p = event.getPlayer();
		
		if(a.equals(Action.LEFT_CLICK_BLOCK)){
			if(p.getItemInHand().getType().equals(Material.WOOD_SWORD)){
				if(CoreSetting.ing){
					GameData.Core.put(event.getClickedBlock().getLocation(), CoreSetting.TeamName);
					Location l=event.getClickedBlock().getLocation();
					Bukkit.broadcastMessage(CoreSetting.TeamName+" ���� �ھ "+l.getX()+", "+l.getY()+", "+l.getZ()+"���� �����Ǿ����ϴ�.");
					CoreSetting.ing=false;
				}
			}
		}
		
		if (GameHandler.Start)
		{
			String playerName = event.getPlayer().getName();
			Ability ability= GameData.PlayerAbility.get(playerName);
			if (ability != null && ability.activeType)
			{
				ability.T_Active(event);
			}
			
			if(a==Action.RIGHT_CLICK_AIR||a==Action.RIGHT_CLICK_BLOCK){
			ItemStack gold = p.getItemInHand();
			if(gold.getType().equals(Material.GOLD_INGOT)){
				Gambling.Module(p);
			}
			}
			}	
		}
	
	
	@EventHandler
	public static void onEntityDamage(EntityDamageEvent event)
	{
		if (GameHandler.Start)
		{
			if (event.getEntity() instanceof Player)
			{
				String playerName = ((Player)event.getEntity()).getName();
				
				if (GameData.PlayerAbility.containsKey(playerName))
					GameData.PlayerAbility.get(playerName).T_Passive(event);
			}
			if (event.getCause() == DamageCause.LIGHTNING && event.getEntity() instanceof LivingEntity)
			{
				LivingEntity le = (LivingEntity) event.getEntity();
				le.setNoDamageTicks(0);
			}
		}
	}
	
	@EventHandler
	public static void onEntityDamageByEntity(EntityDamageByEntityEvent event)
	{
		try
		{
			if (GameHandler.Start)
			{
				if (event.getEntity() instanceof Player &&
						event.getDamager() instanceof Player)
				{
					String key1 = ((Player)event.getEntity()).getName();
					String key2 = ((Player)event.getDamager()).getName();
					Ability ability1 = GameData.PlayerAbility.get(key1);
					Ability ability2 = GameData.PlayerAbility.get(key2);
					if (ability1 != null)
						ability1.T_Passive(event);
					if (ability2 != null)
						ability2.T_Passive(event);					
				}		
				else if (event.getDamager() instanceof Arrow &&
						 event.getEntity() instanceof Player)
				{
					Arrow arrow = (Arrow) event.getDamager();
					if (arrow.getShooter() instanceof Player)
					{
						Player player = (Player) arrow.getShooter();
						String key = player.getName();
						Ability ability = GameData.PlayerAbility.get(key);
						if (ability != null && ability.abilityCode == 7 ||
											   ability.abilityCode == 101)
							ability.T_Passive(event);
					}
				}else if(event.getDamager() instanceof Snowball
						  &&event.getEntity() instanceof Player){
					Snowball snow=(Snowball)event.getDamager();
					if(snow.getShooter() instanceof Player){
						Player player=(Player)snow.getShooter();
						Ability ability=GameData.PlayerAbility.get(player.getName());
						if(ability != null && ability.abilityCode==134||ability.abilityCode==135||ability.abilityCode==136)
							ability.T_PassiveSnow(event);
					}
				}
			}
		}
		catch(Exception e)
		{
			Theomachy.log.info("onEntityDamageByEntity Error\n"+e.getMessage());
		}
	}
	public static ArrayList<Ability> PlayerDeathEventList = new ArrayList<Ability>();
	@EventHandler
	public static void onPlayerDeath(PlayerDeathEvent event)
	{
		if (GameHandler.Start)
		{			
			for (Ability e : PlayerDeathEventList)
				e.T_Passive(event);
			Player player = event.getEntity();
			Ability ability = GameData.PlayerAbility.get(player.getName());
			if (ability != null)
				if (ability.abilityCode == 106 || ability.abilityCode == 3 || ability.abilityCode==136 || ability.abilityCode==4 )
					ability.T_Passive(event);
		}
	}
	
	@EventHandler
	public static void onPlayerWalk(PlayerMoveEvent event)
	{
		if (GameHandler.Start)
		{
			Ability a=GameData.PlayerAbility.get(event.getPlayer().getName());
			if(a!=null){
				if (a.abilityCode==138)
					a.T_Passive(event);
			}
		}
	}
	
	@EventHandler
	public static void onPlayerDeath0(PlayerDeathEvent event)
	{
		if (GameHandler.Start)
		{
			if(event.getEntity().getKiller()!=null){
				Ability a=GameData.PlayerAbility.get(event.getEntity().getKiller().getName());
				if(a!=null){
					if(a.abilityCode==138)
						a.T_PassiveKill(event);
				}
			}
		}
	}
	
	@EventHandler
	public static void onFoodLevelChange(FoodLevelChangeEvent event)
	{
		if (GameHandler.Start)
		{
		if (event.getEntity() instanceof Player)
		{
			String playerName = ((Player)event.getEntity()).getName();
			if (GameData.PlayerAbility.containsKey(playerName))
				GameData.PlayerAbility.get(playerName).T_Passive(event);
		}
		}
	}	
	
	@EventHandler
	public static void onEntityDeath(EntityDeathEvent event){
		if (GameHandler.Start)
		{
		if (event.getEntity() instanceof Player)
		{
			String playerName = ((Player)event.getEntity()).getName();
			if (GameData.PlayerAbility.containsKey(playerName))
				GameData.PlayerAbility.get(playerName).T_Passive(event);
		}
		}
	}
	
	@EventHandler
	public static void onEntityRegainHealth(EntityRegainHealthEvent event)
	{
		if (GameHandler.Start)
		{
		if (event.getEntity() instanceof Player)
		{
			String playerName = ((Player)event.getEntity()).getName();
			if (GameData.PlayerAbility.containsKey(playerName))
				GameData.PlayerAbility.get(playerName).T_Passive(event);
		}
		}
	}
	@EventHandler
	public static void onBlockBreak(BlockBreakEvent event)
	{
		if (GameHandler.Start)
		{
			
			String playerName = event.getPlayer().getName();
			Ability ability = GameData.PlayerAbility.get(playerName);
			if (ability != null)
				ability.T_Passive(event);
		}
		
		if(GameData.Core.containsKey(event.getBlock().getLocation())){
			String team = GameData.Core.get(event.getBlock().getLocation());
			String bteam=GameData.PlayerTeam.get(event.getPlayer().getName());
			if(!team.equals(bteam)){
				Bukkit.broadcastMessage("<"+ChatColor.DARK_GRAY+"�ŵ��� ����"+ChatColor.WHITE+"> "+team+" ���� �ھ �������ϴ�!!");
			}else{
				event.getPlayer().sendMessage(ChatColor.GRAY+"������ �Ұ��մϴ�.");
				event.getBlock().getLocation().getBlock().setType(Material.DIAMOND_BLOCK);
			}
		}
		
	}
	
	@EventHandler
	public static void onPlayerRespawn(PlayerRespawnEvent event)
	{
		if (GameHandler.Start)
		{
			Player player = event.getPlayer();
			if (Theomachy.IGNORE_BED)
			{
				if (GameData.PlayerTeam.containsKey(player.getName()))
				{
					String teamName=GameData.PlayerTeam.get(player.getName());
					Location respawnLocation = GameData.SpawnArea.get(teamName);
					if (respawnLocation != null)
						event.setRespawnLocation(respawnLocation);
				}
			}
			else
			{
				if (!event.isBedSpawn() && GameData.PlayerTeam.containsKey(player.getName()))
				{
					String teamName=GameData.PlayerTeam.get(player.getName());
					Location respawnLocation = GameData.SpawnArea.get(teamName);
					if (respawnLocation != null)
						event.setRespawnLocation(respawnLocation);
				}
			}
			Ability ability = GameData.PlayerAbility.get(player.getName());
			if (ability != null)
			{
				if (ability.buffType)
					ability.buff();
				if (ability.abilityCode == 3||ability.abilityCode==132||ability.abilityCode==128||ability.abilityCode==133||ability.abilityCode==138)
					ability.T_Passive(event);
			}
			
			/*if (!Theomachy.IGNORE_BED )
			{
				Location bedSpawnLocation = player.getBedSpawnLocation();
				if (bedSpawnLocation == null)
				{
					if (GameData.PlayerTeam.containsKey(player.getName()))
					{
						String teamName=GameData.PlayerTeam.get(player.getName());
						Location respawnLocation = GameData.SpawnArea.get(teamName);
						if (respawnLocation != null)
							event.setRespawnLocation(respawnLocation);
					}
				}	
			}
			else
			{
				
				if (GameData.PlayerTeam.containsKey(player.getName()))
				{
					String teamName=GameData.PlayerTeam.get(player.getName());
					Location respawnLocation = GameData.SpawnArea.get(teamName);
					if (respawnLocation != null)
						event.setRespawnLocation(respawnLocation);
				}
			}
			*/
		}
	}
	
	@EventHandler
	public void onSignChange(SignChangeEvent event)
	{
		if (GameHandler.Start)
		{
			Ability ability = GameData.PlayerAbility.get(event.getPlayer().getName());
			if (ability != null && ability.abilityCode==119)
				ability.T_Passive(event);
		}
	}
	
	@EventHandler
	public void onBlockPlace(BlockPlaceEvent event)
	{
		if (GameHandler.Start)
		{
			Ability ability = GameData.PlayerAbility.get(event.getPlayer().getName());
			if (ability != null && ability.abilityCode == 119||ability.abilityCode==139||ability.abilityCode==140||ability.abilityCode==141)
				ability.T_Passive(event);
		}
	}
	@EventHandler
	public static void onPlayerJoin(PlayerJoinEvent event)
	{
		Player player=event.getPlayer();
		GameData.OnlinePlayer.put(player.getName(), player);
		if (GameHandler.Start)
		{
			if(Theomachy.NMPK){
				if(player.getHealth()<=4){
					player.setHealth(0);
					Bukkit.broadcastMessage(player.getName()+ChatColor.RED+"�Բ��� ��ų� �÷��̸� �ϴٰ� �ո����� ���ư����ϴ�.");
				}
			}
			
			Ability ability = GameData.PlayerAbility.get(player.getName());
			if (ability != null && (ability.abilityCode == 2 || ability.abilityCode == 9))
					ability.conditionSet();
		}
	}

	@EventHandler
	public static void onPlayerQuit(PlayerQuitEvent event)
	{
		Player player=event.getPlayer();
		GameData.OnlinePlayer.remove(player.getName());
	}
	
	@EventHandler
	public static void onPlayerKick(PlayerKickEvent event)
	{
		Theomachy.log.info(event.getReason());
	}
	
	@EventHandler
	public static void onEntityExplode(EntityExplodeEvent event)
	{
		Entity entity = event.getEntity();
		if (GameHandler.Start && entity != null && entity.getType() == EntityType.FIREBALL)
			event.blockList().clear();
		if(GameHandler.Start){
			for(Player p:Bukkit.getOnlinePlayers()){
				Ability ability=GameData.PlayerAbility.get(p.getName());
				if(ability!=null&&ability.abilityCode==137){
					ability.T_Passive(event);
				}
			}
		}
	}
	
	@EventHandler
	public static void onInventoryClick(InventoryClickEvent e){
		if(!ChatColor.stripColor(e.getInventory().getName()).equalsIgnoreCase("����"))
			 return;
			e.setCancelled(true);
			if(e.getCurrentItem()==null || e.getCurrentItem().getType()==Material.AIR||!e.getCurrentItem().hasItemMeta()) {
				 return;
			}
		switch(e.getCurrentItem().getType()){
		
		case WOOL:
			ItemStack c=e.getCurrentItem();
			switch(c.getItemMeta().getDisplayName()){
			case "���� ���� �� �κ��丮 Ŭ����":
				if(c.getDurability()==5){
					Theomachy.INVENTORY_CLEAR=false;
					c.setDurability((short)14);
				}else{
					Theomachy.INVENTORY_CLEAR=true;
					c.setDurability((short)5);
				}
				break;
			case "���� ���� �� ��ī�̺��� ������ ����":
				if(c.getDurability()==5){
					Theomachy.GIVE_ITEM=false;
					c.setDurability((short)14);
				}else{
					Theomachy.GIVE_ITEM=true;
					c.setDurability((short)5);
				}
				break;
			case "���� ���� �� ��ƼƼ ����":
				if(c.getDurability()==5){
					Theomachy.ENTITIES_REMOVE=false;
					c.setDurability((short)14);
				}else{
					Theomachy.ENTITIES_REMOVE=true;
					c.setDurability((short)5);
				}
				break;
			case "���� ���似�̺�":
				if(c.getDurability()==5){
					Theomachy.AUTO_SAVE=false;
					c.setDurability((short)14);
				}else{
					Theomachy.AUTO_SAVE=true;
					c.setDurability((short)5);
				}
				break;
			case "���� ����":
				if(c.getDurability()==5){
					Theomachy.ANIMAL=false;
					c.setDurability((short)14);
				}else{
					Theomachy.ANIMAL=true;
					c.setDurability((short)5);
				}
				break;
			case "���� ����":
				if(c.getDurability()==5){
					Theomachy.MONSTER=false;
					c.setDurability((short)14);
				}else{
					Theomachy.MONSTER=true;
					c.setDurability((short)5);
				}
				break;
			case "ħ�� ����":
				if(c.getDurability()==5){
					Theomachy.IGNORE_BED=false;
					c.setDurability((short)14);
				}else{
					Theomachy.IGNORE_BED=true;
					c.setDurability((short)5);
				}
				break;
			case "Ŀ�ǵ� ����":
				if(c.getDurability()==5){
					Theomachy.COMMAND_GAMBLING=false;
					c.setDurability((short)14);
				}else{
					Theomachy.COMMAND_GAMBLING=true;
					c.setDurability((short)5);
				}
				break;
			case "���� ���� �� �ݱ� ����":
				if(c.getDurability()==5){
					Theomachy.GIVE_GOLD=false;
					c.setDurability((short)14);
				}else{
					Theomachy.GIVE_GOLD=true;
					c.setDurability((short)5);
				}
				break;
			case "��ų� �÷��̾� ų":
				if(c.getDurability()==5){
					Theomachy.NMPK=false;
					c.setDurability((short)14);
				}else{
					Theomachy.NMPK=true;
					c.setDurability((short)5);
				}
				break;
			case "�� ä��":
				if(c.getDurability()==5){
					Theomachy.TEAM_CHAT=false;
					c.setDurability((short)14);
				}else{
					Theomachy.TEAM_CHAT=true;
					c.setDurability((short)5);
				}
				break;
			}
		default:
			break;
		}
	}

	@EventHandler
	public static void onChat(PlayerChatEvent e){
		if(Theomachy.TEAM_CHAT){
			e.setCancelled(true);
			List<Player> teamMember=GetPlayerList.getTeamMember(e.getPlayer());
			for(Player p:teamMember){
				p.sendMessage("<"+e.getPlayer().getName()+"> "+e.getMessage());
			}for(String s:GameData.Managers){
				GameData.OnlinePlayer.get(s).sendMessage("<"+e.getPlayer().getName()+"> "+e.getMessage());
			}
		}
	}
	
}
	