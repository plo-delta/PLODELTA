package septagram.Theomachy.Handler.CommandModule;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import septagram.Theomachy.Theomachy;
import septagram.Theomachy.Ability.Ability;
import septagram.Theomachy.Ability.GOD.Apollon;
import septagram.Theomachy.Ability.GOD.Aprodite;
import septagram.Theomachy.Ability.GOD.Ares;
import septagram.Theomachy.Ability.GOD.Artemis;
import septagram.Theomachy.Ability.GOD.Asclepius;
import septagram.Theomachy.Ability.GOD.Athena;
import septagram.Theomachy.Ability.GOD.Baekho;
import septagram.Theomachy.Ability.GOD.CoroSense;
import septagram.Theomachy.Ability.GOD.Demeter;
import septagram.Theomachy.Ability.GOD.Dionysus;
import septagram.Theomachy.Ability.GOD.Eris;
import septagram.Theomachy.Ability.GOD.Hades;
import septagram.Theomachy.Ability.GOD.Hephaestus;
import septagram.Theomachy.Ability.GOD.Hera;
import septagram.Theomachy.Ability.GOD.Hermes;
import septagram.Theomachy.Ability.GOD.Hyeonmu;
import septagram.Theomachy.Ability.GOD.Jujack;
import septagram.Theomachy.Ability.GOD.Morpious;
import septagram.Theomachy.Ability.GOD.Poseidon;
import septagram.Theomachy.Ability.GOD.Rimos;
import septagram.Theomachy.Ability.GOD.Zeus;
import septagram.Theomachy.Ability.HUMAN.Acidsnow;
import septagram.Theomachy.Ability.HUMAN.Anorexia;
import septagram.Theomachy.Ability.HUMAN.Archer;
import septagram.Theomachy.Ability.HUMAN.Assasin;
import septagram.Theomachy.Ability.HUMAN.Bamboohelicopter;
import septagram.Theomachy.Ability.HUMAN.Bean;
import septagram.Theomachy.Ability.HUMAN.Bee;
import septagram.Theomachy.Ability.HUMAN.Blacksmith;
import septagram.Theomachy.Ability.HUMAN.Blast;
import septagram.Theomachy.Ability.HUMAN.Blinder;
import septagram.Theomachy.Ability.HUMAN.Bomber;
import septagram.Theomachy.Ability.HUMAN.Boom;
import septagram.Theomachy.Ability.HUMAN.Boxer;
import septagram.Theomachy.Ability.HUMAN.Butler;
import septagram.Theomachy.Ability.HUMAN.Clayman;
import septagram.Theomachy.Ability.HUMAN.Clocking;
import septagram.Theomachy.Ability.HUMAN.Crazysnow;
import septagram.Theomachy.Ability.HUMAN.Creeper;
import septagram.Theomachy.Ability.HUMAN.GTA;
import septagram.Theomachy.Ability.HUMAN.Gardener;
import septagram.Theomachy.Ability.HUMAN.Goldenspoon;
import septagram.Theomachy.Ability.HUMAN.Invincibility;
import septagram.Theomachy.Ability.HUMAN.Magnet;
import septagram.Theomachy.Ability.HUMAN.Meteor;
import septagram.Theomachy.Ability.HUMAN.Miner;
import septagram.Theomachy.Ability.HUMAN.Miner2;
import septagram.Theomachy.Ability.HUMAN.OV;
import septagram.Theomachy.Ability.HUMAN.Priest;
import septagram.Theomachy.Ability.HUMAN.ProjectileMaster;
import septagram.Theomachy.Ability.HUMAN.Reflection;
import septagram.Theomachy.Ability.HUMAN.Sniper;
import septagram.Theomachy.Ability.HUMAN.Snowman;
import septagram.Theomachy.Ability.HUMAN.Stance;
import septagram.Theomachy.Ability.HUMAN.Teleporter;
import septagram.Theomachy.Ability.HUMAN.Teleporter2;
import septagram.Theomachy.Ability.HUMAN.Training;
import septagram.Theomachy.Ability.HUMAN.Voodoo;
import septagram.Theomachy.Ability.HUMAN.Witch;
import septagram.Theomachy.Ability.HUMAN.Wizard;
import septagram.Theomachy.Ability.HUMAN.Woolmagician;
import septagram.Theomachy.Ability.HUMAN.Zoan;
import septagram.Theomachy.DB.GameData;
import septagram.Theomachy.Utility.CodeHelper;
import septagram.Theomachy.Utility.PermissionChecker;
import septagram.Theomachy.Utility.RandomNumberConstuctor;

public class AbilitySet
{	
	public static void Module(CommandSender sender, Command command, String label, String[] data)
	{
		if (PermissionChecker.Sender(sender))
		{
			if (!GameHandler.Ready)
			{
				if (data.length<=1)
				{
					sender.sendMessage("/t a help   ��� �ɷ��� �ڵ�ǥ�� Ȯ���մϴ�.");
					sender.sendMessage("/t a random ���� ������ ��� �÷��̾�� �������� �ɷ��� �Ҵ��մϴ�.");
					sender.sendMessage("/t a remove <Player> �ش� �÷��̾��� �ɷ��� �����մϴ�.");
					sender.sendMessage("/t a reset  ��� �ɷ��� �ʱ�ȭ �մϴ�");
					sender.sendMessage("/t a <AbilityCode> <Player>  �÷��̾�� �ش� �ɷ��� �����մϴ�.");
				}
				else if (data[1].equalsIgnoreCase("help"))
					CodeHelper.ShowAbilityCodeNumber(sender);
				else if (data[1].equalsIgnoreCase("remove"))//����
				{
					if (data[2] != null)
						Remove(sender, data[2]);
					else
						sender.sendMessage("�ɷ��� ������ �÷��̾��� �̸��� �����ּ���.");
				}
				else if (data[1].equalsIgnoreCase("reset"))//����
					Reset();
				else if (data[1].equalsIgnoreCase("random"))//����
					RandomAssignment(sender);
				else if (data.length >= 3)
					forceAssignment(sender, data);	
				else
				{
					sender.sendMessage("�߸��� �Է��Դϴ�.");
					sender.sendMessage("/t a �� ���ɾ Ȯ���ϼ���.");
				}
			}
			else
				sender.sendMessage("���� ���� �Ŀ��� �ɷ��� ���� �� �� �����ϴ�.");
		}
	}
	
	public static void Remove(CommandSender sender, String playerName)
	{
		Ability ability = GameData.PlayerAbility.get(playerName);
		if (ability != null)
		{
			GameData.PlayerAbility.remove(playerName);
			sender.sendMessage("�÷��̾��� �ɷ��� �����Ͽ����ϴ�.");
		}
		else
			sender.sendMessage("�÷��̾��� �ɷ��� �����ϴ�.");
	}
	
	public static void Reset()
	{
		GameData.PlayerAbility.clear();
		Bukkit.broadcastMessage(ChatColor.AQUA+"�����ڰ� ����� �ɷ��� �ʱ�ȭ �Ͽ����ϴ�.");
	}
	
	private static void RandomAssignment(CommandSender sender)
	{
		if (!GameData.PlayerAbility.isEmpty())
		{
			Bukkit.broadcastMessage("��� �ɷ��� ���� �� �� ����÷�մϴ�.");
			GameData.PlayerAbility.clear();
		}
		Player[] playerlist=Bukkit.getOnlinePlayers();
		Bukkit.broadcastMessage(ChatColor.DARK_AQUA+"�νĵ� �÷��̾� ���");
		for(Player e : playerlist)
			Bukkit.broadcastMessage(ChatColor.GOLD+"  "+e.getName());
		int[] rn = RandomNumberConstuctor.nonDuplicate();
		int length = playerlist.length>Theomachy.Canlist.size() ? Theomachy.Canlist.size() : playerlist.length;
		for (int i=0; i<length ;i++)//i�� �÷��̾� ����Ʈ�� ������
		{
			String playerName = playerlist[i].getName();
			abiltiyAssignment(rn[i],playerName,sender);
		}
		Bukkit.broadcastMessage("��ο��� �ɷ��� ����Ǿ����ϴ�.");
		Bukkit.broadcastMessage("/t help �� Ȯ���غ�����.");
		if (playerlist.length>Theomachy.Canlist.size()){
			Bukkit.broadcastMessage("�ο��� �ʹ� �����ϴ�. ���ο��� �ɷ��� �Ҵ����� ���߽��ϴ�.");
		}
	}
	
	private static void forceAssignment(CommandSender sender, String[] data)
	{
		for (int i=2; i<data.length; i++)
		{
		String abilityName = data[1];
		String playerName=data[i];
		if (GameData.OnlinePlayer.containsKey(playerName))
		{
			try{
				int abilityCode = Integer.parseInt(abilityName);
				abiltiyAssignment(abilityCode, playerName, sender);
				Player player = GameData.OnlinePlayer.get(playerName);
				Bukkit.broadcastMessage("�����ڰ� "+ChatColor.RED+playerName+ChatColor.WHITE+" ���� �ɷ��� �Ҵ��Ͽ����ϴ�.");
				player.sendMessage("�ɷ��� �Ҵ�Ǿ����ϴ�. /t help�� �ɷ��� Ȯ���غ�����.");
			}
			catch (NumberFormatException e)
			{sender.sendMessage("�ɷ��ڵ�� �ڿ����� �Է��� �ּ���");}
		}
		else
			sender.sendMessage(playerName+" �� �ش��ϴ� �¶��� ������ �����ϴ�.");
		}
	}
	
	private static void abiltiyAssignment(int abilityCode, String playerName, CommandSender sender)
	{
		
		if (abilityCode == 1)
			GameData.PlayerAbility.put(playerName, new Zeus(playerName));
		else if (abilityCode == 2)
			GameData.PlayerAbility.put(playerName, new Poseidon(playerName));
		else if (abilityCode == 3)
			GameData.PlayerAbility.put(playerName, new Hades(playerName));
		else if (abilityCode == 4)
			GameData.PlayerAbility.put(playerName, new Athena(playerName));
		else if (abilityCode == 5)
			GameData.PlayerAbility.put(playerName, new Apollon(playerName));
		else if (abilityCode == 6)
			GameData.PlayerAbility.put(playerName, new Artemis(playerName));
		else if (abilityCode == 7)
			GameData.PlayerAbility.put(playerName, new Ares(playerName));
		else if (abilityCode == 8)
			GameData.PlayerAbility.put(playerName, new Asclepius(playerName));
		else if (abilityCode == 9)
			GameData.PlayerAbility.put(playerName, new Hermes(playerName));
		else if (abilityCode == 10)
			GameData.PlayerAbility.put(playerName, new Dionysus(playerName));
		else if (abilityCode==11)
			GameData.PlayerAbility.put(playerName, new Demeter(playerName));
		else if(abilityCode==12)
			GameData.PlayerAbility.put(playerName, new Hephaestus(playerName));
		else if	(abilityCode==13)
			GameData.PlayerAbility.put(playerName, new Rimos(playerName));
		else if (abilityCode==14)
			GameData.PlayerAbility.put(playerName, new Eris(playerName));
		else if (abilityCode==15)
			GameData.PlayerAbility.put(playerName, new Morpious(playerName));
		else if (abilityCode==16)
			GameData.PlayerAbility.put(playerName, new Aprodite(playerName));
		else if (abilityCode==17)
			GameData.PlayerAbility.put(playerName, new Hera(playerName));
		else if (abilityCode==18)
			GameData.PlayerAbility.put(playerName, new Jujack(playerName));
		else if (abilityCode==19)
			GameData.PlayerAbility.put(playerName, new Hyeonmu(playerName));
		else if (abilityCode==20)
			GameData.PlayerAbility.put(playerName, new Baekho(playerName));
		else if (abilityCode==21)
			GameData.PlayerAbility.put(playerName, new CoroSense(playerName));
		//�� ��             �� �ΰ�
		else if (abilityCode == 101)
			GameData.PlayerAbility.put(playerName, new Archer(playerName));
		else if (abilityCode == 102)
			GameData.PlayerAbility.put(playerName, new Miner(playerName));
		else if (abilityCode == 103)
			GameData.PlayerAbility.put(playerName, new Stance(playerName));
		else if (abilityCode == 104)
			GameData.PlayerAbility.put(playerName, new Teleporter(playerName));
		else if (abilityCode == 105)
			GameData.PlayerAbility.put(playerName, new Bomber(playerName));
		else if (abilityCode == 106)
			GameData.PlayerAbility.put(playerName, new Creeper(playerName));
		else if (abilityCode == 107)
			GameData.PlayerAbility.put(playerName, new Assasin(playerName));
		else if (abilityCode == 108)
			GameData.PlayerAbility.put(playerName, new Blinder(playerName));
		else if (abilityCode == 109)
			GameData.PlayerAbility.put(playerName, new Invincibility(playerName));
		else if (abilityCode == 110)
			GameData.PlayerAbility.put(playerName, new Clocking(playerName));
		else if (abilityCode == 111)
			GameData.PlayerAbility.put(playerName, new Blacksmith(playerName));
		else if (abilityCode == 112)
			GameData.PlayerAbility.put(playerName, new Boxer(playerName));
		else if (abilityCode == 113)
			GameData.PlayerAbility.put(playerName, new Priest(playerName));
		else if (abilityCode == 114)
			GameData.PlayerAbility.put(playerName, new Witch(playerName));
		else if (abilityCode == 115)
			GameData.PlayerAbility.put(playerName, new Meteor(playerName));
		else if (abilityCode == 116)
			GameData.PlayerAbility.put(playerName, new Sniper(playerName));
		else if (abilityCode == 117)
			GameData.PlayerAbility.put(playerName, new Voodoo(playerName));
		else if (abilityCode == 118)
			GameData.PlayerAbility.put(playerName, new Miner2(playerName));
		else if	(abilityCode == 119)
			GameData.PlayerAbility.put(playerName, new Wizard(playerName));
		else if (abilityCode==120)
			GameData.PlayerAbility.put(playerName, new Reflection(playerName));
		else if	(abilityCode==121)
			GameData.PlayerAbility.put(playerName, new Bamboohelicopter(playerName));
		else if	(abilityCode==122)
			GameData.PlayerAbility.put(playerName, new Clayman(playerName));
		else if (abilityCode==123)
			GameData.PlayerAbility.put(playerName, new Bean(playerName));
		else if (abilityCode==124)
			GameData.PlayerAbility.put(playerName, new Gardener(playerName));
		else if (abilityCode==125)
			GameData.PlayerAbility.put(playerName, new Bee(playerName));
		else if (abilityCode==126)
			GameData.PlayerAbility.put(playerName, new Magnet(playerName));
		else if (abilityCode==127)
			GameData.PlayerAbility.put(playerName, new Anorexia(playerName));
		else if (abilityCode==128)
			GameData.PlayerAbility.put(playerName, new Blast(playerName));
		else if (abilityCode==129)
			GameData.PlayerAbility.put(playerName, new Boom(playerName));
		else if (abilityCode==130)
			GameData.PlayerAbility.put(playerName, new Training(playerName));
		else if (abilityCode==131)
			GameData.PlayerAbility.put(playerName, new Zoan(playerName));
		else if (abilityCode==132)
			GameData.PlayerAbility.put(playerName, new Goldenspoon(playerName));
		else if (abilityCode==133)
			GameData.PlayerAbility.put(playerName, new Woolmagician(playerName));
		else if (abilityCode==134)
			GameData.PlayerAbility.put(playerName, new Snowman(playerName));
		else if (abilityCode==135)
			GameData.PlayerAbility.put(playerName, new Acidsnow(playerName));
		else if (abilityCode==136)
			GameData.PlayerAbility.put(playerName, new Crazysnow(playerName));
		else if (abilityCode==137)
			GameData.PlayerAbility.put(playerName, new Butler(playerName));
		else if (abilityCode==138)
			GameData.PlayerAbility.put(playerName, new GTA(playerName));
		else if (abilityCode==139)
			GameData.PlayerAbility.put(playerName, new ProjectileMaster(playerName));
		else if (abilityCode==140)
			GameData.PlayerAbility.put(playerName, new Teleporter2(playerName));
		else if (abilityCode==141)
			GameData.PlayerAbility.put(playerName, new OV(playerName));
		else
		{
			sender.sendMessage("�ɷ� �ڵ带 �߸��Է� �ϼ̽��ϴ�. ");
			sender.sendMessage("/t a help ���ɾ�� �ɷ� �ڵ带 Ȯ���Ͻ� �� �ֽ��ϴ�.");
		}
	}
}