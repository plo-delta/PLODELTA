package septagram.Theomachy.Utility;

import java.util.Random;

import septagram.Theomachy.Theomachy;

public class RandomNumberConstuctor
{
	public static int[] nonDuplicate()
	{
		Random random=new Random();
		Object[] r1n=Theomachy.Canlist.toArray();
		int rn[]=new int[r1n.length];
		for(int i=0;i<r1n.length;i++){
			rn[i]=(int)r1n[i];
		}
		
		for(int i=0; i<rn.length; i++)//����
		{
			int r=random.nextInt(rn.length-1);
			int temp=rn[i];
			rn[i]=rn[r];
			rn[r]=temp;
		}
		
		StringBuilder sb = new StringBuilder();
		for (int num : rn)
			sb.append(num).append(" ");
		Theomachy.log.info(String.valueOf(sb));
		return rn;
	}
}
