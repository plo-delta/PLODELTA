package septagram.Theomachy.Timer.Skill;

import java.util.TimerTask;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;

public class ClaymanCautionTimer extends TimerTask{
	Player player;
	private int count=3;
	
	public ClaymanCautionTimer(Player p) {
		this.player=p;
	}

	
	@Override
	public void run() {
		if(count==0){
			player.sendMessage(ChatColor.GOLD+"�ΰ����� ���ƿԽ��ϴ�... ���Ӱ� ������ Ǯ�Ƚ��ϴ�...");
			player.removePotionEffect(PotionEffectType.DAMAGE_RESISTANCE);
			player.removePotionEffect(PotionEffectType.SLOW);
			count--;
		}
		else if(count<=-1){
			
		}
		else{
			player.sendMessage(ChatColor.GOLD+"���� "+ChatColor.RED+"���� "+ChatColor.AQUA+count+ChatColor.WHITE+"�� ���Դϴ�.");
			count--;
		}

	}
	
}
