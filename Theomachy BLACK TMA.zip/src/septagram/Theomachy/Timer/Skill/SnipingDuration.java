package septagram.Theomachy.Timer.Skill;

import java.util.TimerTask;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import septagram.Theomachy.Ability.HUMAN.Sniper;

public class SnipingDuration extends TimerTask {

	final Sniper sniper;
	final Player player;
	int count = 4;
	
	public SnipingDuration(Player player, Sniper sniper)
	{
		this.sniper=sniper;
		this.player = player;
	}
	
	@Override
	public void run()
	{
		if (count > 0)
			player.sendMessage(ChatColor.RED+"[�������� ���] "+ChatColor.WHITE+count+"�� ��");
		else if (count == 0)
		{
			player.sendMessage(ChatColor.RED+"[�������� ���] "+ChatColor.AQUA+"����");
			sniper.sniping = true;
		}
		if (!player.isSneaking())
		{
			sniper.ready=false;
			sniper.sniping=false;
			player.sendMessage(ChatColor.RED+"[�������� ���] "+ChatColor.RED+"����");
			this.cancel();
		}
		count--;
	}

}
