package septagram.Theomachy.Ability.GOD;

import java.util.Random;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import septagram.Theomachy.Theomachy;
import septagram.Theomachy.Ability.Ability;
import septagram.Theomachy.DB.GameData;
import septagram.Theomachy.Timer.CoolTime;
import septagram.Theomachy.Utility.CoolTimeChecker;
import septagram.Theomachy.Utility.EventFilter;
import septagram.Theomachy.Utility.PlayerInventory;
import septagram.Theomachy.Utility.Skill;

public class Artemis extends Ability
{	
	private final int coolTime1=20;
	private final int coolTime2=180;
	private final int material=4;
	private final int stack1=7;
	private final int stack2=15;
	
	public Artemis(String playerName)
	{
		super(playerName,"Artemis", 7, true, true, false);
		Theomachy.log.info(playerName+abilityName);
	}
	
	public void description()
	{
		Player player = GameData.OnlinePlayer.get(playerName);
		player.sendMessage(ChatColor.DARK_GREEN+"=================== "+ChatColor.YELLOW+"�ɷ� ����"+ChatColor.DARK_GREEN+" ===================");
		player.sendMessage(ChatColor.YELLOW+"[ �Ƹ��׹̽� ]  "+ChatColor.RED+"[ �� ]  "+ChatColor.BLUE+"ACTIVE, PASSIVE  "+ChatColor.GREEN+"RANK[ S ]");
		player.sendMessage("��ɰ� ���� ���Դϴ�.\n"+
						   "ȭ��� Ȱ�� ���൹�� �ٲ� �� �ֽ��ϴ�. (��Ŭ�� : ȭ�� 1��, ��Ŭ�� : Ȱ 1��)\n" +
						   "ȭ��� ���ݴ��� �÷��̾�� 20% Ȯ���� ����մϴ�.\n" +
						   ChatColor.AQUA+"�Ϲ�(��Ŭ��) "+ChatColor.WHITE+" ���൹ "+stack1+"�� �Ҹ�, ��Ÿ�� "+coolTime1+"��\n" +
						   ChatColor.RED+"����(��Ŭ��) "+ChatColor.WHITE+" ���൹ "+stack2+"�� �Ҹ�, ��Ÿ�� "+coolTime2+"��\n");
	}
	
	public void T_Active(PlayerInteractEvent event)
	{
		Player player = event.getPlayer();
		if (PlayerInventory.InHandItemCheck(player, 369))
		{
			switch(EventFilter.PlayerInteract(event))
			{
			case 0:case 1:
				leftAction(player);
				break;
			case 2:case 3:
				rightAction(player);
				break;
			}
		}
	}

	private void leftAction(Player player)
	{
		if (CoolTimeChecker.Check(player, 1)&&PlayerInventory.ItemCheck(player, material, stack1))
		{
			Skill.Use(player, material, stack1, 1, coolTime1);
			World world = player.getWorld();
			Location location = player.getLocation();
			world.dropItem(location, new ItemStack(Material.ARROW, 1));
		}
	}
	
	private void rightAction(Player player)
	{
		if (CoolTimeChecker.Check(player, 2)&&PlayerInventory.ItemCheck(player, material, stack2))
		{
			Skill.Use(player, material, stack2, 2, coolTime2);
			World world = player.getWorld();
			Location location = player.getLocation();
			world.dropItem(location, new ItemStack(Material.BOW, 1));
		}
	}
	
	public void T_Passive(EntityDamageByEntityEvent event)
	{
		
		Arrow arrow = (Arrow) event.getDamager();
		Player player = (Player) arrow.getShooter();
		Player target = (Player) event.getEntity();
		
		if (!CoolTime.COOL0.containsKey(target.getName()+"1"))//���� �ڵ� 1��
		{
			Random random = new Random();
			if (random.nextInt(5) == 0)//1/5Ȯ��
			{
				event.setDamage(100);
				player.sendMessage("ȭ���� ��ǥ�� ������ �վ����ϴ�!");
				target.sendMessage("�Ƹ��׹̽����� ���߽��ϴ�!");
			}
		}
	}	
}
