package septagram.Theomachy.Ability.GOD;

import java.util.Timer;
import java.util.TimerTask;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import septagram.Theomachy.Theomachy;
import septagram.Theomachy.Ability.Ability;
import septagram.Theomachy.DB.GameData;

public class Hyeonmu extends Ability{

	public Hyeonmu(String playerName) {
		super(playerName, "Hyeonmu", 19, false, true, true);
		Theomachy.log.info(playerName+abilityName);
	}
	
	public void description()
	{
		Player player = GameData.OnlinePlayer.get(playerName);
		player.sendMessage(ChatColor.DARK_GREEN+"=================== "+ChatColor.YELLOW+"�ɷ� ����"+ChatColor.DARK_GREEN+" ===================");
		player.sendMessage(ChatColor.YELLOW+"[ ���� ]  "+ChatColor.RED+"[ ��ż� ]  "+ChatColor.BLUE+"PASSIVE, BUFF  "+ChatColor.GREEN+"RANK[ A ]");
		player.sendMessage("��ż� �� �ź����Դϴ�.\n"+
						   "�ڽ��� ������ ��뿡�� �ݰ��Ͽ� 1�������� �ݴϴ�.\n" +
						   "�⺻ �нú�� ���� ���� �޽��ϴ�." );
	}
	
	public void T_Passive(EntityDamageByEntityEvent e){
		Player player=(Player)e.getEntity();
		Player target=(Player)e.getDamager();
		if(player.getName().equals(playerName)){
			target.damage(1);
		}
	}
	
	public void buff(){
		Player player=GameData.OnlinePlayer.get(playerName);
		if(player!=null){
			Timer t=new Timer();
			t.schedule(new regis(player), 1000);
		}
	}
	
	private class regis extends TimerTask{

		final Player p;
		
		public regis(Player p){
			this.p=p;
		}
		
		@Override
		public void run() {
			p.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE,86400, 0));
		}
		
	}
	
}
