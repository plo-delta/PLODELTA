package septagram.Theomachy.Ability.GOD;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import septagram.Theomachy.Theomachy;
import septagram.Theomachy.Ability.Ability;
import septagram.Theomachy.DB.GameData;
import septagram.Theomachy.Utility.CoolTimeChecker;
import septagram.Theomachy.Utility.EventFilter;
import septagram.Theomachy.Utility.PlayerInventory;
import septagram.Theomachy.Utility.Skill;

public class Hera extends Ability{

	public Hera(String playerName) {
		super(playerName, "Hera", 17, true, false, false);
		Theomachy.log.info(playerName+abilityName);
	}
	
	private final int stack0=15;
	private final int coolTime0=500;
	
	public void description()
	{
		Player player = GameData.OnlinePlayer.get(playerName);
		player.sendMessage(ChatColor.DARK_GREEN+"=================== "+ChatColor.YELLOW+"�ɷ� ����"+ChatColor.DARK_GREEN+" ===================");
		player.sendMessage(ChatColor.YELLOW+"[ ��� ]  "+ChatColor.RED+"[ �� ]  "+ChatColor.BLUE+"ACTIVE  "+ChatColor.GREEN+"RANK[ A ]");
		player.sendMessage("������ �����Դϴ�.\n"+
							"�ɷ��� ���� ��Ŭ�� �� �ڽ��� ������ ��� �ڽ��� �ڸ��� ���̰� �մϴ�.\n"+
						   ChatColor.AQUA+"(��Ŭ��) "+ChatColor.WHITE+" ���൹ "+stack0+"�� �Ҹ�, ��Ÿ�� "+coolTime0+"��\n");
	}
	
	public void T_Active(PlayerInteractEvent event){
			Player player = event.getPlayer();
			if (PlayerInventory.InHandItemCheck(player, 369))
			{
				switch(EventFilter.PlayerInteract(event))
				{
				case 0:case 1:
					leftAction(player);
					break;
				}
		}
	}

	private void leftAction(Player player) {
		if(CoolTimeChecker.Check(player, 0)&&PlayerInventory.ItemCheck(player, 4, stack0)){
			Skill.Use(player, 4, stack0, 0, coolTime0);
			String teamName1=GameData.PlayerTeam.get(player.getName());
			for(Player p:Bukkit.getOnlinePlayers()){
				String teamName2=GameData.PlayerTeam.get(p.getName());
				if(teamName1.equals(teamName2)){
					p.teleport(player);
					p.sendMessage(ChatColor.LIGHT_PURPLE+"������ ���ſ� ���� �������� TP�˴ϴ�.");
				}
			}
		}
	}
	
}
