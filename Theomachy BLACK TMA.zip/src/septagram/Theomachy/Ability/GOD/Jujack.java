package septagram.Theomachy.Ability.GOD;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import septagram.Theomachy.Theomachy;
import septagram.Theomachy.Ability.Ability;
import septagram.Theomachy.DB.GameData;
import septagram.Theomachy.Utility.CoolTimeChecker;
import septagram.Theomachy.Utility.ParticleEffect;
import septagram.Theomachy.Utility.PlayerInventory;
import septagram.Theomachy.Utility.Skill;

public class Jujack extends Ability{

	public Jujack(String playerName) {
		super(playerName, "Jujack", 18, true, false, true);
		Theomachy.log.info(playerName+abilityName);
	}

	private int stack0=10;
	private int coolTime0=5;
	
	public void description()
	{
		Player player = GameData.OnlinePlayer.get(playerName);
		player.sendMessage(ChatColor.DARK_GREEN+"=================== "+ChatColor.YELLOW+"�ɷ� ����"+ChatColor.DARK_GREEN+" ===================");
		player.sendMessage(ChatColor.YELLOW+"[ ���� ]  "+ChatColor.RED+"[ ��ż� ]  "+ChatColor.BLUE+"ACTIVE, BUFF  "+ChatColor.GREEN+"RANK[ S ]");
		player.sendMessage("��ż� �� ���� ���Դϴ�.\n"+
						   "������ �������� ����� ������ 4�������� �Բ� ������ �ҿ� �۽��Դϴ�.\n" +
						   "�⺻ ������ ȭ�������� �޽��ϴ�.\n" +
						   ChatColor.AQUA+"(������ �������� ����� ���� ��) "+ChatColor.WHITE+" ���൹ "+stack0+"�� �Ҹ�, ��Ÿ�� "+coolTime0+"��");
	}
	
	public void buff(){
		Player player = GameData.OnlinePlayer.get(playerName);
		if(player != null){
			Timer t=new Timer();
			t.schedule(new fire(player), 1000);
		}
	}
	
	private class fire extends TimerTask{
		final Player p;
		
		public fire(Player p){
			this.p=p;
		}
		public void run(){
			p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 86400, 0));
		}
	}
	
	public void T_Passive(EntityDamageByEntityEvent event){
		Player target=(Player)event.getEntity();
		Player player=(Player)event.getDamager();
		if(player.getName().equals(playerName)){
			if(PlayerInventory.InHandItemCheck(player, 369)){
				if(CoolTimeChecker.Check(player, 0)&&PlayerInventory.ItemCheck(player, 4, stack0)){
					Skill.Use(player, 4, stack0, 0, coolTime0);
					player.getWorld().playSound(player.getLocation(), Sound.BLAZE_BREATH, 1.0f, 1.0f);
					List<Player> playerlist=new ArrayList<Player>();
					for(Player p:Bukkit.getOnlinePlayers()){
						playerlist.add(p);
					}
					ParticleEffect.FLAME.display(0, 0, 0, 1, 30, target.getLocation(), playerlist);
					event.setDamage(4);
					target.setFireTicks(20*6);
				}
			}
		}
	}
	
}
