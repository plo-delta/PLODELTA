package septagram.Theomachy.Ability.HUMAN;

import java.util.Random;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;

import septagram.Theomachy.Theomachy;
import septagram.Theomachy.Ability.Ability;
import septagram.Theomachy.DB.GameData;

public class Boom extends Ability{

	public Boom(String playerName) {
		super(playerName, "Boom", 129, false, true, false);
		Theomachy.log.info(playerName+abilityName);
	}
	
	public void description()
	{
		Player player = GameData.OnlinePlayer.get(playerName);
		player.sendMessage(ChatColor.DARK_GREEN+"=================== "+ChatColor.YELLOW+"�ɷ� ����"+ChatColor.DARK_GREEN+" ===================");
		player.sendMessage(ChatColor.YELLOW+"[ ���� ]  "+ChatColor.RED+"[ �ΰ� ]  "+ChatColor.BLUE+"PASSIVE  "+ChatColor.GREEN+"RANK[ S ]");
		player.sendMessage("������ �����ϴ�.\n"+
						   "Į�� ���� ���� �� 25%�� Ȯ���� 2.5�� ������ ����ŵ�ϴ�.\n"+
						   "��, ����Į�̳� ��Į�� �ش���� �ʽ��ϴ�.");
	}
	
	public void T_Passive(EntityDamageByEntityEvent event){
		Player damager  = (Player)event.getDamager();
		Player boom = (Player)event.getEntity();
		
		ItemStack gi = damager.getItemInHand();
		Material w = Material.GOLD_SWORD;
		Material i = Material.IRON_SWORD;
		Material d = Material.DIAMOND_SWORD;
		
		if(boom.getName().equals(playerName)){
			if(gi.getType()==w||gi.getType()==i||gi.getType()==d){
				Random r = new Random();
				int rn = r.nextInt(4);
				if(rn==0){
					Location l = boom.getLocation();
					World world = boom.getWorld();
					world.createExplosion(l, 2.5f);
				}
			}
		}
	}
}
