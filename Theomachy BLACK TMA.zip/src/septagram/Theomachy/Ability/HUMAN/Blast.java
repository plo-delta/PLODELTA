package septagram.Theomachy.Ability.HUMAN;


import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;


import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;

import septagram.Theomachy.Theomachy;
import septagram.Theomachy.Ability.Ability;
import septagram.Theomachy.DB.GameData;

public class Blast extends Ability{

	public Blast(String playerName) {
		super(playerName, "Blast", 128, false, true, false);
		Theomachy.log.info(playerName+abilityName);
	}
	
	public void description()
	{
		Player player = GameData.OnlinePlayer.get(playerName);
		player.sendMessage(ChatColor.DARK_GREEN+"=================== "+ChatColor.YELLOW+"�ɷ� ����"+ChatColor.DARK_GREEN+" ===================");
		player.sendMessage(ChatColor.YELLOW+"[ �뱤�� ]  "+ChatColor.RED+"[ �ΰ� ]  "+ChatColor.BLUE+"PASSIVE  "+ChatColor.GREEN+"RANK[ A ]");
		player.sendMessage("�Ұ� ���õ� �������� ������ �� ���� 10�ʵ��� ���� �� �ֽ��ϴ�.\n"+
						   "���� ������ ������ 1���� ���� �� �ֽ��ϴ�.\n");
	}
	
	public void T_Passive(EntityDamageEvent event){
		Player p = (Player)event.getEntity();
		if(event.getCause()==DamageCause.FIRE){
			p.addPotionEffect(new PotionEffect(PotionEffectType.getById(5), 200, 0), true);
		}
	}

	public void T_Passive(PlayerRespawnEvent event){
		Player p = event.getPlayer();
		p.getInventory().addItem(new ItemStack(Material.FLINT_AND_STEEL));
	}
	
}


