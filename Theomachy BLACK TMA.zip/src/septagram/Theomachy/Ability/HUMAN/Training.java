package septagram.Theomachy.Ability.HUMAN;

import java.util.Random;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import septagram.Theomachy.Theomachy;
import septagram.Theomachy.Ability.Ability;
import septagram.Theomachy.DB.GameData;

public class Training extends Ability{

	public Training(String playerName) {
		super(playerName, "Training", 130, false, true, false);
		Theomachy.log.info(playerName+abilityName);
	}
	
	public void description()
	{
		Player player = GameData.OnlinePlayer.get(playerName);
		player.sendMessage(ChatColor.DARK_GREEN+"=================== "+ChatColor.YELLOW+"�ɷ� ����"+ChatColor.DARK_GREEN+" ===================");
		player.sendMessage(ChatColor.YELLOW+"[ ���� ]  "+ChatColor.RED+"[ �ΰ� ]  "+ChatColor.BLUE+"PASSIVE  "+ChatColor.GREEN+"RANK[ B ]");
		player.sendMessage("�� ������ ������ 15% Ȯ���� �� ���� 5�ʵ��� ����ϴ�.");
	}
	
	public void T_Passive(EntityDamageByEntityEvent event){
		
		Player p = (Player)event.getEntity();
		Player d = (Player)event.getDamager();
		
		if(p.getName().equals(playerName)){
			if(d.getItemInHand().equals(Material.AIR)){
				Random r = new Random();
				int rn = r.nextInt(20);
				if(rn<=2){
				p.addPotionEffect(new PotionEffect(PotionEffectType.getById(5), 20*5, 0));
				}
			}
		}
	}
}
