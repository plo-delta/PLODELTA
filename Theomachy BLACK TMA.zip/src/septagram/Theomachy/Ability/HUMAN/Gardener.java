package septagram.Theomachy.Ability.HUMAN;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

import septagram.Theomachy.Theomachy;
import septagram.Theomachy.Ability.Ability;
import septagram.Theomachy.DB.GameData;

public class Gardener extends Ability{
	
	public Gardener(String playerName) {
		super(playerName, "Gardener", 124, true, true, false);
		Theomachy.log.info(playerName+abilityName);
	}
	
	public void description(){
		Player player = GameData.OnlinePlayer.get(playerName);
		player.sendMessage(ChatColor.DARK_GREEN+"=================== "+ChatColor.YELLOW+"�ɷ� ����"+ChatColor.DARK_GREEN+" ===================");
		player.sendMessage(ChatColor.YELLOW+"[ ������ ]  "+ChatColor.RED+"[ �ΰ� ]  "+ChatColor.BLUE+"PASSIVE  "+ChatColor.GREEN+"RANK[ A ]");
		player.sendMessage("������ ���۵Ǹ� ���� 5���� �� 10���� �޽��ϴ�.\n"+
								  "������ Ķ ������ �� 1���̿� �� 2���� �޽��ϴ�.\n"
								);
	}
	
	public void T_Passive(BlockBreakEvent event)
	{
		if(event.getBlock().getTypeId()==17){
			event.getPlayer().getWorld().dropItemNaturally(event.getBlock().getLocation(), new ItemStack(38, 1));
			event.getPlayer().getWorld().dropItemNaturally(event.getBlock().getLocation(), new ItemStack(4, 2));
		}
	}
	
	public void conditionSet(){
		GameData.OnlinePlayer.get(playerName).getInventory().addItem(new ItemStack(6, 5));
		GameData.OnlinePlayer.get(playerName).getInventory().addItem(new ItemStack(352, 10));
	}

}
