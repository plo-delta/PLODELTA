package septagram.Theomachy.Ability.HUMAN;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerInteractEvent;

import septagram.Theomachy.Theomachy;
import septagram.Theomachy.Ability.Ability;
import septagram.Theomachy.DB.GameData;
import septagram.Theomachy.Timer.Skill.OVFlying;
import septagram.Theomachy.Utility.CoolTimeChecker;
import septagram.Theomachy.Utility.EventFilter;
import septagram.Theomachy.Utility.PlayerInventory;
import septagram.Theomachy.Utility.Skill;

public class OV extends Ability{

	private final int coolTime0=60;
	private final int material=4;
	private final int stack0=10;
	public static boolean isFlying=false;
	public static Location preLoc;
	public static int task;
	
	public OV(String playerName) {
		super(playerName, "Omniscient", 141, true, false, false);
		Theomachy.log.info(playerName+abilityName);
	}
	
	public void description()
	{
		Player player = GameData.OnlinePlayer.get(playerName);
		player.sendMessage(ChatColor.DARK_GREEN+"=================== "+ChatColor.YELLOW+"�ɷ� ����"+ChatColor.DARK_GREEN+" ===================");
		player.sendMessage(ChatColor.YELLOW+"[ ������ �۰� ]  "+ChatColor.RED+"[ �ΰ� ]  "+ChatColor.BLUE+"ACTIVE  "+ChatColor.GREEN+"RANK[ A ]");
		player.sendMessage("�������� �۰��� �Ǿ� ���� ���ƴٳ຾�ô�!\n"+
						   "�ɷ��� ���븦 ����ϸ� �����ڰ� �Ǿ� ���� ������ �� �ֽ��ϴ�.\n" +
						   "�����ڴ� ���Ƽ� ������ ���� ������, 30�� �Ŀ� ���ڸ��� ���ƿɴϴ�.\n" +
						   ChatColor.GREEN+"(��Ŭ��) "+ChatColor.WHITE+" ���൹ "+stack0+"�� �Ҹ�, ��Ÿ�� "+coolTime0+"��\n");
	}
	
	public void T_Active(PlayerInteractEvent event){
		Player player = event.getPlayer();
		if (PlayerInventory.InHandItemCheck(player, 369))
		{
			switch(EventFilter.PlayerInteract(event))
			{
			case 0:case 1:
				leftAction(player);
				break;
			}
		}
	}
	
	@SuppressWarnings("deprecation")
	private void leftAction(Player player) {
		if (CoolTimeChecker.Check(player, 0)&&PlayerInventory.ItemCheck(player, material, stack0))
		{
			if(!isFlying){
				Skill.Use(player, material, stack0, 0, coolTime0);
				Bukkit.getScheduler().scheduleAsyncRepeatingTask(Theomachy.t, new OVFlying(player), 20L, 20L);
			}else{
				player.sendMessage("���� ���캸�� ���Դϴ�!");
			}
		}
	}
	
	public void T_Passive(EntityDamageByEntityEvent e){
		if(isFlying)
			e.setCancelled(true);
	}
	
	public void T_Passive(EntityDamageEvent e){
		if(isFlying)
			e.setCancelled(true);
	}
	
	public void T_Passive(BlockPlaceEvent e){
		if(isFlying)
			e.setCancelled(true);
	}
	
	public void T_Passive(BlockBreakEvent e){
		if(isFlying)
			e.setCancelled(true);
	}
	
	public void T_Passive(ProjectileLaunchEvent e){
		if(isFlying)
			e.setCancelled(true);
	}
	
}
