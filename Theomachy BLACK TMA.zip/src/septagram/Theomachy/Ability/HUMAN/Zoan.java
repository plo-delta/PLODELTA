package septagram.Theomachy.Ability.HUMAN;

import java.util.Random;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

import septagram.Theomachy.Theomachy;
import septagram.Theomachy.Ability.Ability;
import septagram.Theomachy.DB.GameData;
import septagram.Theomachy.Utility.CoolTimeChecker;
import septagram.Theomachy.Utility.EventFilter;
import septagram.Theomachy.Utility.PlayerInventory;
import septagram.Theomachy.Utility.Skill;
import septagram.Theomachy.Utility.ZoanBase;

public class Zoan extends Ability{

	private int stack0 = 64;
	private int coolTime0 = 300;
	private int material = 4;
	
	public Zoan(String playerName) {
		super(playerName, "Zoan", 131, true, false, false);
		Theomachy.log.info(playerName+abilityName);
	}
	
	public void description()
	{
		Player player = GameData.OnlinePlayer.get(playerName);
		player.sendMessage(ChatColor.DARK_GREEN+"=================== "+ChatColor.YELLOW+"�ɷ� ����"+ChatColor.DARK_GREEN+" ===================");
		player.sendMessage(ChatColor.YELLOW+"[ ������������ ]  "+ChatColor.RED+"[ �ΰ� ]  "+ChatColor.BLUE+"ACTIVE  "+ChatColor.GREEN+"RANK[ S ]");
		player.sendMessage("�پ��� ������ ������ �� �ֽ��ϴ�.\n" +
						   	"���� �߰��� �� �����Դϴ�.\n" +
						   	ChatColor.AQUA+"(��Ŭ��) "+ChatColor.WHITE+" ���൹ "+stack0+"�� �Ҹ�, ��Ÿ�� "+coolTime0+"��\n");
	}
	
	public void T_Active(PlayerInteractEvent event){
		Player player = event.getPlayer();
		if (PlayerInventory.InHandItemCheck(player, 369))
		{
			switch(EventFilter.PlayerInteract(event))
			{
			case 0:case 1:
				leftAction(player);
				break;
			}
		}
	}
	
	private void leftAction(Player p){
		if(CoolTimeChecker.Check(p, 0)&&PlayerInventory.ItemCheck(p, 4, stack0)){
			Skill.Use(p, material, stack0, 0, coolTime0);
			Random r = new Random();
			int rn=r.nextInt(5);
			ZoanBase.zoan(p, rn);
		}
		
	}
}
