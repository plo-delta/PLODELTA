package septagram.Theomachy.Ability.HUMAN;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;

import septagram.Theomachy.Theomachy;
import septagram.Theomachy.Ability.Ability;
import septagram.Theomachy.DB.GameData;

public class Goldenspoon extends Ability{

	public Goldenspoon(String playerName) {
		super(playerName, "Goldenspoon", 132, false, true, false);
		Theomachy.log.info(playerName+abilityName);
	}
	
	public void description()
	{
		Player player = GameData.OnlinePlayer.get(playerName);
		player.sendMessage(ChatColor.DARK_GREEN+"=================== "+ChatColor.YELLOW+"�ɷ� ����"+ChatColor.DARK_GREEN+" ===================");
		player.sendMessage(ChatColor.YELLOW+"[ �ݼ��� ]  "+ChatColor.RED+"[ �ΰ� ]  "+ChatColor.BLUE+"PASSIVE  "+ChatColor.GREEN+"RANK[ B ]");
		player.sendMessage("�ݼ����� ���� �¾ �ɷ��Դϴ�.\n"+
						   "������ �� ������ �� ���뽺�� ȹ���մϴ�.\n");
	}
	
	public void T_Passive(PlayerRespawnEvent event){
		Player p=event.getPlayer();
		p.getInventory().addItem(new ItemStack(Material.GOLD_LEGGINGS));
	}
	
}
