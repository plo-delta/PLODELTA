package septagram.Theomachy.Ability.HUMAN;

import java.util.Random;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

import septagram.Theomachy.Theomachy;
import septagram.Theomachy.Ability.Ability;
import septagram.Theomachy.DB.GameData;

public class Bee extends Ability{
	
	public Bee(String playerName) {
		super(playerName, "Bee", 125, false, true, false);
		Theomachy.log.info(playerName+abilityName);
	}
	
	public void description(){
		Player player = GameData.OnlinePlayer.get(playerName);
		player.sendMessage(ChatColor.DARK_GREEN+"=================== "+ChatColor.YELLOW+"�ɷ� ����"+ChatColor.DARK_GREEN+" ===================");
		player.sendMessage(ChatColor.YELLOW+"[ �ܹ� ]  "+ChatColor.RED+"[ �ΰ� ]  "+ChatColor.BLUE+"PASSIVE  "+ChatColor.GREEN+"RANK[ SSS ]");
		player.sendMessage("����ó�� ���Ƽ� ��ó�� ��� �ɷ��Դϴ�.\n"+
						   "�ڽ��� ������ ��뿡�� 75%�� Ȯ���� �� 3�ʸ� �����մϴ�.\n" );
	}
	
	public void T_Passive(EntityDamageByEntityEvent event){
		Player p = (Player)event.getEntity();
		Player t = (Player)event.getDamager();
			
				if(p.getName().equals(playerName)){
					Random random = new Random();
					int dam = random.nextInt(4);
					if(dam!=0){
						p.sendMessage(ChatColor.YELLOW+"��ħ�� �����ϴ�!!");
						t.sendMessage(ChatColor.YELLOW+"��ħ�� �¾ҽ��ϴ�!!");
		
					}
			}
	}
	
	public void T_Passive(EntityDamageEvent event){
		if(event.getCause() == DamageCause.POISON){
			event.setCancelled(true);
		}
	}
}