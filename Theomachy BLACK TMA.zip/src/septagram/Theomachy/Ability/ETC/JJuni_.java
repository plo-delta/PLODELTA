package septagram.Theomachy.Ability.ETC;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import septagram.Theomachy.Theomachy;
import septagram.Theomachy.Ability.Ability;
import septagram.Theomachy.DB.GameData;

public class JJuni_ extends Ability
{
	public JJuni_(String playerName)
	{
		super(playerName,"�޴�", 1869, false, false, false);
		Theomachy.log.info(playerName+abilityName);
	}

	public void description()
	{
		Player player = GameData.OnlinePlayer.get(playerName);
		player.sendMessage(ChatColor.DARK_GREEN+"=================== "+ChatColor.YELLOW+"�ɷ� ����"+ChatColor.DARK_GREEN+" ===================");
		player.sendMessage(ChatColor.YELLOW+"[ �޴� ]  "+ChatColor.RED+"[ BJ ]  "+ChatColor.BLUE+"Unknown  "+ChatColor.GREEN+"Rank[ ? ]");
		player.sendMessage("������ī BJ�Դϴ�.\n" +
						   "�߰�����?������\n");
	}
}
